.. Assignement_2_2022 documentation master file, created by
   sphinx-quickstart on Mon May 15 13:02:03 2023.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to Assignement_2_2022's documentation!
==============================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search

Documentation for assignment_2_2022
**************************************
The documentation provided here pertains to the assignment_2_2022 file, specifically the assignment_2_2022 module.


Control Module
=================================
.. automodule:: scripts.control
  :members:

Counter Module
=================
.. automodule:: scripts.counter
  :members:

rob.info Module
=================
.. automodule:: scripts.rob_info
  :members:



